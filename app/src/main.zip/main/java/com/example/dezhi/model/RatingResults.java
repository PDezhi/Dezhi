package com.example.dezhi.model;

import androidx.annotation.NonNull;

public class RatingResults  implements Comparable{

    private String name;
    private float rating;

    public RatingResults(String name, float rating) {
        this.name = name;
        this.rating = rating;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Meal: " + name + "Rating: " + rating;
    }

    @Override
    public int compareTo(@NonNull Object o) {
        RatingResults otherObject = (RatingResults) o;
        return name.compareTo(otherObject.getName());
    }
}
