package com.example.dezhi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.example.dezhi.model.RatingResults;

import java.io.Serializable;
import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {
//    TextView textViewResult;
//    EditText editTextName;
//    ArrayList<RatingResults> listOfRatingResults;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
//        initialize();
    }

//    private void initialize() {
//        textViewResult = findViewById(R.id.editTextTextMultiLine);
//        editTextName = findViewById(R.id.editTextTextPersonName);
//
//        Bundle bundle = getIntent().getBundleExtra("intentExtra");
//        Serializable bundledListOfRatingResults = bundle.getSerializable("bundleExtra");
//
//        listOfRatingResults = (ArrayList<RatingResults>) bundledListOfRatingResults;
//
//        showListOfRatingResults(listOfRatingResults);
//    }
//
//    private void showListOfRatingResults(ArrayList<RatingResults> listOfStudents) {
//        String str = "";
//        for (RatingResults oneStudent : listOfStudents) {
//            str = str + oneStudent;
//        }
//        textViewResult.setText(str);
//    }
//    public void goBack(){
//        Intent intent = new Intent();
//        intent.putExtra("return_result_tag", editTextName.getText().toString());
//
//        setResult(RESULT_OK, intent);
//        finish();
//
//    }
}